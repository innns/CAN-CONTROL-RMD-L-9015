# import CanControlRMD
import math
import time
import MyUDPServer

MOTOR = [i for i in range(10)]


def D2R(x):
    return x * math.pi / 180.0


def R2D(x):
    return x * 180.0 / math.pi


if __name__ == '__main__':
    # CAN = CanControlRMD.CanControlRMD()

    # UDP socket
    UDP = MyUDPServer.MyUDPServer('127.0.0.1', 5000)
    UDP.listen_threading()
    # 创建一个can 监听线程并启动
    # CAN.recv_can_threading()

    while 1:
        json_data = UDP.get_json_data()
        if 'cmd' in json_data.keys():
            cmd = json_data['cmd']
            if cmd == 'close_ALL':
                UDP.close()
                # CAN.close()
                break
            elif cmd == 'angle':
                # CAN.multi_angle_control(json_data['id'], 0x05, json_data['angel'])
                print("id{} max_spd{} angel{}".format(json_data['id'], 0x05, json_data['angel']))
            elif cmd == 'motion':
                # CAN.motion_control(json_data['id'], json_data['p_des'], json_data['v_des'], 3, 0.2, 0)
                print("id{} p_des{} v_des{}".format(json_data['id'], json_data['p_des'], json_data['v_des']))
            elif cmd == 'position':
                # CAN.multi_angle_control(json_data['id'], 0x0A, int(100 * json_data['angel']))
                print("id{} angel_des{}".format(json_data['id'], json_data['angel']))
            elif cmd == 'set_PID':
                print("id{0} {1} {2} {3} {4} {5} {6} {7}}".format(json_data['id'],
                                                                  json_data['cp'], json_data['ci'],
                                                                  json_data['sp'], json_data['si'],
                                                                  json_data['pp'], json_data['pi'],
                                                                  json_data['save']))
                # CAN.set_PID(json_data['id'],
                #             json_data['cp'], json_data['ci'],
                #             json_data['sp'], json_data['si'],
                #             json_data['pp'], json_data['pi'],
                #             json_data['save'])
            elif cmd == 'close_motor':
                print("CLOSE")
                # CAN.close_motor(json_data['id'])
            elif cmd == 'read':
                print("READ")
                # CAN.read_multi_angel(json_data['id'])
                # CAN.process_recv_can()
                # msg = CAN.get_msg()
                # if msg is not None:
                #     send_data = {'id': msg.motor_id, 'angel': msg.angel}
                #     UDP.send_json_data(send_data)
                #     print("SEND: ", send_data)
            else:
                print(json_data)